class AddExpenseScreen extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _categoryController = TextEditingController();
  final _dateController = TextEditingController();
  final _descriptionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Expense')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _amountController,
              decoration: InputDecoration(labelText: 'Amount'),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value!.isEmpty) return 'Please enter an amount';
                return null;
              },
            ),
            // Add other fields (category, date, description)
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  // Save expense to database
                  final expense = Expense(
                    amount: double.parse(_amountController.text),
                    category: _categoryController.text,
                    date: DateTime.parse(_dateController.text),
                    description: _descriptionController.text,
                  );
                  // Call a function to save the expense (e.g., to Firebase or local DB)
                  saveExpense(expense);
                  Navigator.pop(context);
                }
              },
              child: Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}
